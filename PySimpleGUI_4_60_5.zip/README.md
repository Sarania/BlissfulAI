
## PySimpleGUI Version 4.60.5

This is PySimpleGUI version 4.60.5 licensed under the LGPL v3.0. It is NOT part of the BlissfulAI project and is included strictly under the terms of the LGPL, of which a copy may be located in this directory.
